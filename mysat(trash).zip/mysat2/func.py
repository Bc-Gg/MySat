import copy

from obj import *

def find_unitary(cla:clause):
    for sub_cla in cla.cla:
        if len(sub_cla) == 1:
            return sub_cla.pop()
    return None

def unitary(cla : clause, var ):
    cla.cla = [s for s in cla.cla if len(s) != 0]
    cla.cla_num = len(cla.cla)
    temp_cla = copy.deepcopy(cla.cla)
    for sub_cla in temp_cla:
        if var in sub_cla:
            sub_cla.clear()
    temp_cla = [s for s in temp_cla if len(s) != 0]
    if temp_cla == []:
        cla.cla = []
    else:
        cla.cla = temp_cla
        for sub_cla in cla.cla:
            if -var in sub_cla:
                sub_cla.remove(-var)
    return cla

def select(cla : clause):
    cla.load()
    select_dict = {}
    max_cnt = -1
    max_key = None
    for key in cla.var_cnt.keys():
        if abs(key) in select_dict:
            select_dict[abs(key)] += cla.var_cnt[key]
        else:
            select_dict[abs(key)] = cla.var_cnt[key]
    for key in select_dict.keys():
        if max_cnt < select_dict[key]:
            max_key = key
    # print(f'max_key = {max_key}')
    return max_key

def plain_text(cla: clause):

    plain_text_list = []
    keys = set(cla.var_cnt.keys()).copy()

    for key in keys:
        if -key not in keys:
            plain_text_list.append(key)

    for text in plain_text_list:
        cla.solution[abs(text)] = text / abs(text)
        cla.var_num -= 1
        print(f'text = {text}')
        for sub_cla in cla.cla:
            if text in sub_cla:
                sub_cla.remove(text)
    cla.cla = [s for s in cla.cla if len(s) != 0 ]
    cla.cla_num = len(cla.cla)
    cla.load()
    return cla

def tautology(cla : clause):

    for sub_cla in cla.cla:
        for var in sub_cla:
            if -var in sub_cla:
                cla.cla.remove(sub_cla)
                cla.cla_num -= 1
                break
    return cla
