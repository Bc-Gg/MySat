'''
my sat tool kit
Author : 0764
--version 0.01 时间 2021/11/25
可以应用单子句规则了，重言式规则在一定程度上也可以使用，进行了一些基础性的工作
下次更新重点:1 添加子句sub_clause对象让clause对象可以更灵活的应对重言式规则，纯文字规则
           2 增加time模块的使用，将函数运行时间时间输出，可以尝试使用函数装饰器
一些idea 可以重构一个变元对象，里面存储一些相关的属性，这个可以在后面代码重构的时候可以尝试实现一下
'''
import copy

from func import  *
from obj import  *
import time
solution = {}

def process(cla: clause):
    # print(f'processing -> {cla.cla}')
    while True:
        # print(f'processing in while ->  {cla.cla}')
        var = find_unitary(cla)
        # print(f'var = {var}')
        if var == None:
            break
        else:
            solution[abs(var)] = var / abs(var)
            cla = unitary(cla,var)
        # print(f"cla.cla = {cla.cla}")
        if cla.cla == []:
            return True
        elif set() in cla.cla:
            return False
    add_key = select(cla)
    temp1 = copy.deepcopy(cla.cla)
    temp2 = copy.deepcopy(cla.cla)
    temp1.append(({add_key}))
    if process(clause(temp1)):
        return True
    else:
        temp2.append(({-add_key}))
        return process(clause(temp2))


def main():
    # ------------------ input && initialize---------------------
    content = "请输入变元个数和子句个数，随后输入n行子句，子句以0结尾\nPS:变元数从1开始编号\n"
    var_num, cla_num = tuple(map(int,input(content).split()))
    clause_input = []
    for _ in range(cla_num):
        sub_cla_temp = list(map(int, input().split()))[:-1]
        clause_input.append(set(sub_cla_temp))
    print("your input clause is:",clause_input)
    my_cla = clause(clause_input)
    # ---------------------  processing --------------------------
    # while my_cla.cla_num == 0:
    #     pass
    start = time.perf_counter()
    keys = process(my_cla)
    end = time.perf_counter()
    print('Running time: %s Seconds' % (end - start))
    # 这里返回的keys 还要做
    # ----------------------- output -------------------------------
    if keys :
        print("SAT")
        print(f'solution = {solution}')
        # my_cla.show()
    else :
        print("UNSAT")
if __name__ == '__main__':
    main()